export interface FormData {
  // Dados Pessoais
  nomeCompleto: string;
  idade: number;
  sexo: 'M' | 'F';
  altura: number;
  peso: number;
  email: string;
  telefone: string;

  // Histórico de Saúde
  condicaoSaude: string;
  usoMedicamentos: string;
  alergias: string;

  // Hábitos Alimentares
  classificacaoAlimentacao: string;
  restricoesAlimentares: string;
  refeicoesDiarias: number;
  jejumIntermitente: string;
  consumoDiario: string;

  // Rotina e Exercícios
  nivelAtividadeFisica: string;
  tipoExercicio: string;
  horarioTreino: string;

  // Objetivo e Preferências
  objetivo: string;
  preferenciaDieta: string;
  alimentosNaoGosta: string;
  preferenciaReceitas: 'praticas' | 'elaboradas';

  // Confirmação
  aceitaTermos: boolean;
}

export interface IMCResult {
  valor: number;
  classificacao: string;
}