import React, { useState } from 'react';
import { Dumbbell, Mail, FileCheck, Activity, Trophy } from 'lucide-react';
import { FormData, IMCResult } from './types';
import { calcularIMC, classificarIMC } from './utils/imc';
import { FormSection } from './components/FormSection';
import { FormField } from './components/FormField';

function App() {
  const [formData, setFormData] = useState<FormData>({
    nomeCompleto: '',
    idade: 0,
    sexo: 'M',
    altura: 0,
    peso: 0,
    email: '',
    telefone: '',
    condicaoSaude: '',
    usoMedicamentos: '',
    alergias: '',
    classificacaoAlimentacao: '',
    restricoesAlimentares: '',
    refeicoesDiarias: 3,
    jejumIntermitente: '',
    consumoDiario: '',
    nivelAtividadeFisica: '',
    tipoExercicio: '',
    horarioTreino: '',
    objetivo: '',
    preferenciaDieta: '',
    alimentosNaoGosta: '',
    preferenciaReceitas: 'praticas',
    aceitaTermos: false,
  });

  const [imcResult, setImcResult] = useState<IMCResult | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.peso || !formData.altura) {
      alert('Por favor, preencha peso e altura corretamente.');
      return;
    }
    
    const imc = calcularIMC(formData.peso, formData.altura);
    const classificacao = classificarIMC(imc);
    
    setImcResult({ valor: imc, classificacao });
    setIsSubmitting(true);

    try {
      const response = await fetch('https://hooks.zapier.com/hooks/catch/22059956/2lktct0/', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        mode: 'cors',
        body: JSON.stringify({ ...formData, imc, classificacao }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      setShowSuccess(true);
    } catch (error) {
      console.error('Erro ao enviar dados:', error);
      // Even if the API call fails, we'll show the success page
      // since we already calculated the IMC
      setShowSuccess(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : 
              (type === 'number' ? (value ? parseFloat(value) : 0) : value),
    }));
  };

  if (showSuccess && imcResult) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-900 via-green-700 to-green-900 flex items-center justify-center p-4">
        <div className="max-w-2xl w-full bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-8 border border-green-100">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-green-600 p-4 rounded-full">
                <Trophy className="w-12 h-12 text-white" />
              </div>
            </div>
            
            <h2 className="text-3xl font-bold text-green-600 mb-6">
              Parabéns, {formData.nomeCompleto}!
            </h2>

            <div className="bg-gradient-to-r from-green-50 via-white to-green-50 rounded-xl p-6 mb-8 border border-green-100 shadow-inner">
              <div className="flex justify-center mb-4">
                <Activity className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Seu IMC é: {imcResult.valor}</h3>
              <p className="text-lg text-gray-700 mb-4">Classificação: {imcResult.classificacao}</p>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-green-600 transition-all duration-500"
                  style={{ width: `${Math.min((imcResult.valor / 40) * 100, 100)}%` }}
                ></div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="bg-white rounded-lg p-6 shadow-md border border-green-100">
                <Mail className="w-6 h-6 text-green-600 mx-auto mb-3" />
                <h4 className="text-lg font-semibold mb-2">Kit VidaFit Enviado!</h4>
                <p className="text-gray-600">
                  Verifique seu email para acessar seu plano personalizado
                </p>
              </div>

              <div className="bg-white rounded-lg p-6 shadow-md border border-green-100">
                <FileCheck className="w-6 h-6 text-green-600 mx-auto mb-3" />
                <h4 className="text-lg font-semibold mb-2">Conteúdo Exclusivo</h4>
                <p className="text-gray-600">
                  Cardápios, receitas e vídeo treinos personalizados
                </p>
              </div>
            </div>

            <div className="bg-green-50 rounded-lg p-6 border border-green-100">
              <h4 className="text-lg font-semibold mb-3">Próximos Passos:</h4>
              <ol className="text-left text-gray-700 space-y-2">
                <li className="flex items-start">
                  <span className="bg-green-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">1</span>
                  <span>Abra seu email e acesse o Kit VidaFit completo</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-green-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">2</span>
                  <span>Revise seu plano alimentar personalizado</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-green-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">3</span>
                  <span>Comece seus treinos com os vídeos exclusivos</span>
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-green-700 to-green-900 relative">
      <div className="absolute inset-0 opacity-5" 
           style={{
             backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
           }}
      ></div>
      
      <div className="max-w-4xl mx-auto px-4 py-12 relative">
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-8 border border-green-100">
          <div className="flex items-center justify-center mb-8">
            <div className="bg-green-600 p-3 rounded-full">
              <Dumbbell className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-800 ml-4">Kit VidaFit</h1>
          </div>

          <div className="bg-gradient-to-r from-green-50 via-white to-green-50 rounded-lg p-6 mb-8 border border-green-100 shadow-inner">
            <p className="text-lg text-gray-700 text-center">
              Descubra seu IMC e Ganhe um Kit VidaFit Completo – Totalmente Grátis: Cardápios e receitas personalizados + Cronograma completo + Vídeo treinos exclusivos
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <FormSection title="Dados Pessoais">
              <FormField label="Nome Completo" required>
                <input
                  type="text"
                  name="nomeCompleto"
                  value={formData.nomeCompleto}
                  onChange={handleInputChange}
                  required
                  className="form-input rounded-lg border-gray-300 w-full"
                />
              </FormField>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField label="Idade" required>
                  <input
                    type="number"
                    name="idade"
                    value={formData.idade || ''}
                    onChange={handleInputChange}
                    required
                    min="0"
                    className="form-input rounded-lg border-gray-300 w-full"
                  />
                </FormField>

                <FormField label="Sexo" required>
                  <select
                    name="sexo"
                    value={formData.sexo}
                    onChange={handleInputChange}
                    required
                    className="form-select rounded-lg border-gray-300 w-full"
                  >
                    <option value="M">Masculino</option>
                    <option value="F">Feminino</option>
                  </select>
                </FormField>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField label="Altura (cm)" required>
                  <input
                    type="number"
                    name="altura"
                    value={formData.altura || ''}
                    onChange={handleInputChange}
                    required
                    min="0"
                    className="form-input rounded-lg border-gray-300 w-full"
                  />
                </FormField>

                <FormField label="Peso (kg)" required>
                  <input
                    type="number"
                    name="peso"
                    value={formData.peso || ''}
                    onChange={handleInputChange}
                    required
                    min="0"
                    step="0.1"
                    className="form-input rounded-lg border-gray-300 w-full"
                  />
                </FormField>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField label="Email" required>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="form-input rounded-lg border-gray-300 w-full"
                  />
                </FormField>

                <FormField label="Telefone" required>
                  <input
                    type="tel"
                    name="telefone"
                    value={formData.telefone}
                    onChange={handleInputChange}
                    required
                    className="form-input rounded-lg border-gray-300 w-full"
                  />
                </FormField>
              </div>
            </FormSection>

            <FormSection title="Histórico de Saúde">
              <FormField label="Condição de saúde diagnosticada">
                <textarea
                  name="condicaoSaude"
                  value={formData.condicaoSaude}
                  onChange={handleInputChange}
                  className="form-textarea rounded-lg border-gray-300 w-full"
                  rows={3}
                />
              </FormField>

              <FormField label="Uso de medicamentos regularmente">
                <textarea
                  name="usoMedicamentos"
                  value={formData.usoMedicamentos}
                  onChange={handleInputChange}
                  className="form-textarea rounded-lg border-gray-300 w-full"
                  rows={2}
                />
              </FormField>

              <FormField label="Alergias ou intolerâncias alimentares">
                <textarea
                  name="alergias"
                  value={formData.alergias}
                  onChange={handleInputChange}
                  className="form-textarea rounded-lg border-gray-300 w-full"
                  rows={2}
                />
              </FormField>
            </FormSection>

            <FormSection title="Hábitos Alimentares e Estilo de Vida">
              <FormField label="Como classifica sua alimentação?" required>
                <select
                  name="classificacaoAlimentacao"
                  value={formData.classificacaoAlimentacao}
                  onChange={handleInputChange}
                  required
                  className="form-select rounded-lg border-gray-300 w-full"
                >
                  <option value="">Selecione...</option>
                  <option value="saudavel">Muito saudável</option>
                  <option value="regular">Regular</option>
                  <option value="ruim">Precisa melhorar</option>
                </select>
              </FormField>

              <FormField label="Restrições alimentares">
                <textarea
                  name="restricoesAlimentares"
                  value={formData.restricoesAlimentares}
                  onChange={handleInputChange}
                  className="form-textarea rounded-lg border-gray-300 w-full"
                  rows={2}
                />
              </FormField>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField label="Quantidade de refeições diárias" required>
                  <input
                    type="number"
                    name="refeicoesDiarias"
                    value={formData.refeicoesDiarias}
                    onChange={handleInputChange}
                    required
                    min="1"
                    className="form-input rounded-lg border-gray-300 w-full"
                  />
                </FormField>

                <FormField label="Prática de jejum intermitente">
                  <input
                    type="text"
                    name="jejumIntermitente"
                    value={formData.jejumIntermitente}
                    onChange={handleInputChange}
                    placeholder="Ex: 16/8, 18/6, não pratico"
                    className="form-input rounded-lg border-gray-300 w-full"
                  />
                </FormField>
              </div>

              <FormField label="Consumo diário de água, açúcares e ultraprocessados">
                <textarea
                  name="consumoDiario"
                  value={formData.consumoDiario}
                  onChange={handleInputChange}
                  className="form-textarea rounded-lg border-gray-300 w-full"
                  rows={3}
                />
              </FormField>
            </FormSection>

            <FormSection title="Rotina e Exercícios">
              <FormField label="Nível de atividade física" required>
                <select
                  name="nivelAtividadeFisica"
                  value={formData.nivelAtividadeFisica}
                  onChange={handleInputChange}
                  required
                  className="form-select rounded-lg border-gray-300 w-full"
                >
                  <option value="">Selecione...</option>
                  <option value="sedentario">Sedentário</option>
                  <option value="leve">Levemente ativo</option>
                  <option value="moderado">Moderadamente ativo</option>
                  <option value="muito">Muito ativo</option>
                </select>
              </FormField>

              <FormField label="Tipo de exercício praticado">
                <input
                  type="text"
                  name="tipoExercicio"
                  value={formData.tipoExercicio}
                  onChange={handleInputChange}
                  className="form-input rounded-lg border-gray-300 w-full"
                />
              </FormField>

              <FormField label="Horário preferido para treinar">
                <input
                  type="text"
                  name="horarioTreino"
                  value={formData.horarioTreino}
                  onChange={handleInputChange}
                  className="form-input rounded-lg border-gray-300 w-full"
                />
              </FormField>
            </FormSection>

            <FormSection title="Objetivo e Preferências">
              <FormField label="Principal objetivo" required>
                <textarea
                  name="objetivo"
                  value={formData.objetivo}
                  onChange={handleInputChange}
                  required
                  className="form-textarea rounded-lg border-gray-300 w-full"
                  rows={2}
                />
              </FormField>

              <FormField label="Preferência por algum tipo de dieta">
                <input
                  type="text"
                  name="preferenciaDieta"
                  value={formData.preferenciaDieta}
                  onChange={handleInputChange}
                  className="form-input rounded-lg border-gray-300 w-full"
                />
              </FormField>

              <FormField label="Alimentos que não gosta">
                <textarea
                  name="alimentosNaoGosta"
                  value={formData.alimentosNaoGosta}
                  onChange={handleInputChange}
                  className="form-textarea rounded-lg border-gray-300 w-full"
                  rows={2}
                />
              </FormField>

              <FormField label="Preferência por receitas" required>
                <select
                  name="preferenciaReceitas"
                  value={formData.preferenciaReceitas}
                  onChange={handleInputChange}
                  required
                  className="form-select rounded-lg border-gray-300 w-full"
                >
                  <option value="praticas">Práticas e rápidas</option>
                  <option value="elaboradas">Elaboradas</option>
                </select>
              </FormField>
            </FormSection>

            <div className="flex items-center space-x-2 mb-6">
              <input
                type="checkbox"
                name="aceitaTermos"
                checked={formData.aceitaTermos}
                onChange={handleInputChange}
                required
                className="form-checkbox h-5 w-5 text-green-600 rounded"
              />
              <label className="text-sm text-gray-700">
                Concordo em receber orientações personalizadas com base nos dados informados
              </label>
            </div>

            <div className="flex justify-center">
              <button
                type="submit"
                disabled={isSubmitting}
                className={`bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl ${isSubmitting ? 'opacity-75 cursor-not-allowed' : ''}`}
              >
                {isSubmitting ? 'Calculando...' : 'Descobrir meu IMC'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default App;